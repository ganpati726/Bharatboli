import { useState, useRef, useEffect } from "react";

const LANGUAGES = [
  { code: "hi", name: "हिंदी", flag: "🇮🇳", label: "Hindi" },
  { code: "ta", name: "தமிழ்", flag: "🌴", label: "Tamil" },
  { code: "te", name: "తెలుగు", flag: "🌟", label: "Telugu" },
  { code: "bn", name: "বাংলা", flag: "🌸", label: "Bengali" },
  { code: "mr", name: "मराठी", flag: "🦚", label: "Marathi" },
  { code: "gu", name: "ગુજરાતી", flag: "🎨", label: "Gujarati" },
  { code: "kn", name: "ಕನ್ನಡ", flag: "🐘", label: "Kannada" },
  { code: "ml", name: "മലയാളം", flag: "🥥", label: "Malayalam" },
  { code: "pa", name: "ਪੰਜਾਬੀ", flag: "🌾", label: "Punjabi" },
  { code: "or", name: "ଓଡ଼ିଆ", flag: "🏛️", label: "Odia" },
];

const SYSTEM_PROMPTS = {
  hi: `आप BharatBoli AI हैं — भारत का पहला बहुभाषी AI असिस्टेंट। आप हमेशा हिंदी में जवाब दें। आपका लहजा दोस्ताना, सरल और भारतीय संस्कृति से जुड़ा हो। छोटे, स्पष्ट जवाब दें। WhatsApp जैसी बातचीत करें।`,
  ta: `நீங்கள் BharatBoli AI — இந்தியாவின் முதல் பல்மொழி AI உதவியாளர். எப்போதும் தமிழில் பதிலளிக்கவும். நட்பான, எளிய தொனியில் பேசவும். சுருக்கமான பதில்கள் தரவும்.`,
  te: `మీరు BharatBoli AI — భారతదేశపు మొదటి బహుభాషా AI సహాయకుడు. ఎల్లప్పుడూ తెలుగులో సమాధానం ఇవ్వండి. స్నేహపూర్వకంగా, సరళంగా మాట్లాడండి.`,
  bn: `আপনি BharatBoli AI — ভারতের প্রথম বহুভাষিক AI সহকারী। সবসময় বাংলায় উত্তর দিন। বন্ধুত্বপূর্ণ ও সহজ ভাষায় কথা বলুন।`,
  mr: `तुम्ही BharatBoli AI आहात — भारताचे पहिले बहुभाषी AI सहाय्यक. नेहमी मराठीत उत्तर द्या. मैत्रीपूर्ण आणि सोप्या भाषेत बोला.`,
  gu: `તમે BharatBoli AI છો — ભારતના પ્રથમ બહુભાષી AI સહાયક. હંમેશા ગુજરાતીમાં જવાબ આપો. મૈત્રીપૂર્ણ અને સરળ ભાષામાં બોલો.`,
  kn: `ನೀವು BharatBoli AI — ಭಾರತದ ಮೊದಲ ಬಹುಭಾಷಾ AI ಸಹಾಯಕ. ಯಾವಾಗಲೂ ಕನ್ನಡದಲ್ಲಿ ಉತ್ತರಿಸಿ. ಸ್ನೇಹಪೂರ್ವಕ ಮತ್ತು ಸರಳ ಭಾಷೆಯಲ್ಲಿ ಮಾತನಾಡಿ.`,
  ml: `നിങ്ങൾ BharatBoli AI ആണ് — ഇന്ത്യയുടെ ആദ്യത്തെ ബഹുഭാഷാ AI സഹായി. എപ്പോഴും മലയാളത്തിൽ മറുപടി നൽകുക. സൗഹൃദപൂർവ്വമായും ലളിതമായും സംസാരിക്കുക.`,
  pa: `ਤੁਸੀਂ BharatBoli AI ਹੋ — ਭਾਰਤ ਦਾ ਪਹਿਲਾ ਬਹੁਭਾਸ਼ਾਈ AI ਸਹਾਇਕ। ਹਮੇਸ਼ਾ ਪੰਜਾਬੀ ਵਿੱਚ ਜਵਾਬ ਦਿਓ। ਦੋਸਤਾਨਾ ਅਤੇ ਸਰਲ ਭਾਸ਼ਾ ਵਿੱਚ ਗੱਲ ਕਰੋ।`,
  or: `ଆପଣ BharatBoli AI — ଭାରତର ପ୍ରଥମ ବହୁଭାଷୀ AI ସହାୟକ। ସବୁବେଳେ ଓଡ଼ିଆରେ ଉତ୍ତର ଦିଅନ୍ତୁ। ବନ୍ଧୁତ୍ୱପୂର୍ଣ୍ଣ ଏବଂ ସରଳ ଭାଷାରେ କଥା ବଲନ୍ତୁ।`,
};

const WELCOME_MESSAGES = {
  hi: "नमस्ते! 🙏 मैं BharatBoli AI हूं। आज मैं आपकी कैसे मदद कर सकता हूं?",
  ta: "வணக்கம்! 🙏 நான் BharatBoli AI. இன்று நான் உங்களுக்கு எப்படி உதவ முடியும்?",
  te: "నమస్కారం! 🙏 నేను BharatBoli AI. ఈరోజు మీకు ఎలా సహాయం చేయగలను?",
  bn: "নমস্কার! 🙏 আমি BharatBoli AI. আজ আমি আপনাকে কীভাবে সাহায্য করতে পারি?",
  mr: "नमस्कार! 🙏 मी BharatBoli AI आहे. आज मी तुम्हाला कशी मदत करू शकतो?",
  gu: "નમસ્તે! 🙏 હું BharatBoli AI છું. આજે હું તમારી કેવી મદદ કરી શકું?",
  kn: "ನಮಸ್ಕಾರ! 🙏 ನಾನು BharatBoli AI. ಇಂದು ನಾನು ನಿಮಗೆ ಹೇಗೆ ಸಹಾಯ ಮಾಡಬಹುದು?",
  ml: "നമസ്കാരം! 🙏 ഞാൻ BharatBoli AI ആണ്. ഇന്ന് ഞാൻ നിങ്ങളെ എങ്ങനെ സഹായിക്കാം?",
  pa: "ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ! 🙏 ਮੈਂ BharatBoli AI ਹਾਂ। ਅੱਜ ਮੈਂ ਤੁਹਾਡੀ ਕਿਵੇਂ ਮਦਦ ਕਰ ਸਕਦਾ ਹਾਂ?",
  or: "ନମସ୍କାର! 🙏 ମୁଁ BharatBoli AI. ଆଜି ମୁଁ ଆପଣଙ୍କୁ କିପରି ସାହାଯ୍ୟ କରିପାରିବି?",
};

function TypingIndicator() {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 4, padding: "10px 14px", background: "#fff", borderRadius: "18px 18px 18px 4px", maxWidth: 80, boxShadow: "0 1px 2px rgba(0,0,0,0.1)" }}>
      {[0, 1, 2].map(i => (
        <div key={i} style={{
          width: 8, height: 8, borderRadius: "50%", background: "#128C7E",
          animation: "bounce 1.2s infinite",
          animationDelay: `${i * 0.2}s`
        }} />
      ))}
    </div>
  );
}

export default function BharatBoliMVP() {
  const [selectedLang, setSelectedLang] = useState(LANGUAGES[0]);
  const [messages, setMessages] = useState([
    { role: "assistant", text: WELCOME_MESSAGES["hi"], time: new Date() }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [showLangPicker, setShowLangPicker] = useState(false);
  const [conversationHistory, setConversationHistory] = useState([]);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const switchLanguage = (lang) => {
    setSelectedLang(lang);
    setShowLangPicker(false);
    setMessages([{ role: "assistant", text: WELCOME_MESSAGES[lang.code], time: new Date() }]);
    setConversationHistory([]);
  };

  const sendMessage = async () => {
    if (!input.trim() || loading) return;
    const userText = input.trim();
    setInput("");

    const newUserMsg = { role: "user", text: userText, time: new Date() };
    setMessages(prev => [...prev, newUserMsg]);

    const newHistory = [...conversationHistory, { role: "user", content: userText }];
    setConversationHistory(newHistory);
    setLoading(true);

    try {
      // ✅ अब सीधे Anthropic को नहीं, अपने server को call करते हैं
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          system: SYSTEM_PROMPTS[selectedLang.code],
          messages: newHistory,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "API error");
      }

      const replyText = data.content?.map(b => b.text || "").join("") || "माफ़ करें, कुछ गड़बड़ हुई।";

      setConversationHistory(prev => [...prev, { role: "assistant", content: replyText }]);
      setMessages(prev => [...prev, { role: "assistant", text: replyText, time: new Date() }]);
    } catch {
      setMessages(prev => [...prev, { role: "assistant", text: "⚠️ नेटवर्क की समस्या है। फिर से कोशिश करें।", time: new Date() }]);
    } finally {
      setLoading(false);
    }
  };

  const formatTime = (d) => d.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });

  return (
    <div style={{
      fontFamily: "'Segoe UI', sans-serif",
      height: "100vh", display: "flex", flexDirection: "column",
      background: "#ECE5DD",
      maxWidth: 430, margin: "0 auto",
      position: "relative", overflow: "hidden"
    }}>
      <style>{`
        @keyframes bounce { 0%,80%,100%{transform:translateY(0)} 40%{transform:translateY(-6px)} }
        @keyframes fadeIn { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
        @keyframes slideDown { from{opacity:0;transform:translateY(-10px)} to{opacity:1;transform:translateY(0)} }
        .msg-in { animation: fadeIn 0.25s ease; }
        .lang-btn:hover { background: #f0f0f0 !important; }
        textarea:focus { outline: none; }
        textarea { resize: none; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.2); border-radius: 4px; }
      `}</style>

      {/* WhatsApp Header */}
      <div style={{
        background: "linear-gradient(135deg, #075E54 0%, #128C7E 100%)",
        padding: "10px 16px", display: "flex", alignItems: "center", gap: 12,
        boxShadow: "0 2px 8px rgba(0,0,0,0.3)", zIndex: 10, flexShrink: 0
      }}>
        <div style={{ color: "#fff", fontSize: 20, cursor: "pointer" }}>←</div>
        <div style={{
          width: 42, height: 42, borderRadius: "50%",
          background: "linear-gradient(135deg, #FF6B35, #F7931E)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 20, flexShrink: 0, border: "2px solid rgba(255,255,255,0.3)"
        }}>🇮🇳</div>
        <div style={{ flex: 1 }}>
          <div style={{ color: "#fff", fontWeight: 700, fontSize: 16, letterSpacing: 0.3 }}>BharatBoli AI</div>
          <div style={{ color: "rgba(255,255,255,0.8)", fontSize: 12 }}>✨ {selectedLang.flag} {selectedLang.label} में बात करें</div>
        </div>
        <button
          onClick={() => setShowLangPicker(!showLangPicker)}
          style={{
            background: "rgba(255,255,255,0.2)", border: "1px solid rgba(255,255,255,0.4)",
            borderRadius: 20, padding: "5px 12px", color: "#fff",
            cursor: "pointer", fontSize: 13, fontWeight: 600,
            display: "flex", alignItems: "center", gap: 4
          }}
        >
          {selectedLang.flag} भाषा
        </button>
      </div>

      {/* Language Picker */}
      {showLangPicker && (
        <div style={{
          position: "absolute", top: 68, right: 10, zIndex: 200,
          background: "#fff", borderRadius: 12, overflow: "hidden",
          boxShadow: "0 8px 32px rgba(0,0,0,0.2)", minWidth: 200,
          animation: "slideDown 0.2s ease"
        }}>
          {LANGUAGES.map(lang => (
            <button key={lang.code} className="lang-btn"
              onClick={() => switchLanguage(lang)}
              style={{
                width: "100%", textAlign: "left", padding: "11px 16px",
                background: lang.code === selectedLang.code ? "#E8F5E9" : "#fff",
                border: "none", borderBottom: "1px solid #f0f0f0",
                cursor: "pointer", fontSize: 14, display: "flex", alignItems: "center", gap: 10
              }}>
              <span style={{ fontSize: 18 }}>{lang.flag}</span>
              <span style={{ fontWeight: 600 }}>{lang.name}</span>
              <span style={{ color: "#666", fontSize: 12, marginLeft: "auto" }}>{lang.label}</span>
              {lang.code === selectedLang.code && <span style={{ color: "#128C7E" }}>✓</span>}
            </button>
          ))}
        </div>
      )}

      {/* Chat Area */}
      <div style={{
        flex: 1, overflowY: "auto", padding: "12px 10px",
        backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23128C7E' fill-opacity='0.04'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
      }}>
        <div style={{ textAlign: "center", margin: "8px 0 16px" }}>
          <span style={{ background: "rgba(0,0,0,0.15)", color: "#fff", padding: "3px 12px", borderRadius: 10, fontSize: 11 }}>
            आज / Today
          </span>
        </div>

        {messages.map((msg, i) => (
          <div key={i} className="msg-in" style={{
            display: "flex",
            justifyContent: msg.role === "user" ? "flex-end" : "flex-start",
            marginBottom: 6
          }}>
            {msg.role === "assistant" && (
              <div style={{
                width: 28, height: 28, borderRadius: "50%",
                background: "linear-gradient(135deg, #FF6B35, #F7931E)",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 14, marginRight: 6, flexShrink: 0, alignSelf: "flex-end", marginBottom: 2
              }}>🇮🇳</div>
            )}
            <div style={{
              maxWidth: "75%",
              background: msg.role === "user" ? "#DCF8C6" : "#fff",
              borderRadius: msg.role === "user" ? "18px 18px 4px 18px" : "18px 18px 18px 4px",
              padding: "9px 13px 5px",
              boxShadow: "0 1px 2px rgba(0,0,0,0.12)",
            }}>
              <div style={{ fontSize: 14.5, lineHeight: 1.5, color: "#111", wordBreak: "break-word", whiteSpace: "pre-wrap" }}>
                {msg.text}
              </div>
              <div style={{ fontSize: 10, color: "#999", textAlign: "right", marginTop: 3, display: "flex", alignItems: "center", justifyContent: "flex-end", gap: 3 }}>
                {formatTime(msg.time)}
                {msg.role === "user" && <span style={{ color: "#53BDEB" }}>✓✓</span>}
              </div>
            </div>
          </div>
        ))}

        {loading && (
          <div className="msg-in" style={{ display: "flex", alignItems: "flex-end", gap: 6, marginBottom: 6 }}>
            <div style={{ width: 28, height: 28, borderRadius: "50%", background: "linear-gradient(135deg, #FF6B35, #F7931E)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14 }}>🇮🇳</div>
            <TypingIndicator />
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Suggestions */}
      <div style={{ padding: "6px 10px 4px", background: "#fff", borderTop: "1px solid #f0f0f0", display: "flex", gap: 8, overflowX: "auto", flexShrink: 0 }}>
        {[
          selectedLang.code === "hi" ? "मुझे एक कहानी सुनाओ 📖" : selectedLang.code === "ta" ? "ஒரு கதை சொல்லுங்கள் 📖" : "Tell me a story 📖",
          selectedLang.code === "hi" ? "मौसम कैसा है? ☀️" : selectedLang.code === "ta" ? "வானிலை எப்படி? ☀️" : "What's the weather? ☀️",
          selectedLang.code === "hi" ? "एक जोक सुनाओ 😄" : selectedLang.code === "ta" ? "ஒரு நகைச்சுவை சொல்லுங்கள் 😄" : "Tell a joke 😄",
        ].map((s, i) => (
          <button key={i} onClick={() => { setInput(s); inputRef.current?.focus(); }}
            style={{ flexShrink: 0, padding: "5px 12px", borderRadius: 16, border: "1px solid #128C7E", background: "#fff", color: "#128C7E", fontSize: 12, cursor: "pointer", fontWeight: 500, whiteSpace: "nowrap" }}>
            {s}
          </button>
        ))}
      </div>

      {/* Input Bar */}
      <div style={{ padding: "8px 10px", background: "#F0F0F0", display: "flex", alignItems: "flex-end", gap: 8, flexShrink: 0 }}>
        <button style={{ width: 40, height: 40, borderRadius: "50%", border: "none", background: "#fff", cursor: "pointer", fontSize: 20, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, boxShadow: "0 1px 3px rgba(0,0,0,0.1)" }}>😊</button>
        <div style={{ flex: 1, background: "#fff", borderRadius: 22, padding: "8px 14px", boxShadow: "0 1px 3px rgba(0,0,0,0.1)" }}>
          <textarea ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
            placeholder={
              selectedLang.code === "hi" ? "संदेश लिखें..." :
              selectedLang.code === "ta" ? "செய்தி எழுதுங்கள்..." :
              selectedLang.code === "te" ? "సందేశం రాయండి..." : "Type a message..."
            }
            rows={1}
            style={{ width: "100%", border: "none", fontSize: 15, color: "#111", background: "transparent", fontFamily: "inherit", lineHeight: 1.4 }}
          />
        </div>
        <button onClick={sendMessage} disabled={loading}
          style={{
            width: 44, height: 44, borderRadius: "50%", border: "none",
            background: input.trim() ? "linear-gradient(135deg, #128C7E, #075E54)" : "#aaa",
            cursor: input.trim() ? "pointer" : "default",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 18, flexShrink: 0,
            boxShadow: input.trim() ? "0 2px 8px rgba(18,140,126,0.5)" : "none",
            transition: "all 0.2s"
          }}>
          {input.trim() ? "➤" : "🎤"}
        </button>
      </div>

      <div style={{ textAlign: "center", padding: "4px 0 6px", background: "#F0F0F0", fontSize: 10, color: "#aaa", flexShrink: 0 }}>
        🇮🇳 BharatBoli AI • भारत की आवाज़ • Powered by Claude
      </div>

      {showLangPicker && (
        <div onClick={() => setShowLangPicker(false)} style={{ position: "fixed", inset: 0, zIndex: 99 }} />
      )}
    </div>
  );
}
